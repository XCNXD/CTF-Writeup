#!/bin/sh

export CC=arm-gnu-toolchain-12.2.rel1-x86_64-aarch64-none-linux-gnu/bin/aarch64-none-linux-gnu-gcc

$CC -fstack-protector-all -O0 -static -no-pie -o steer steer.c
